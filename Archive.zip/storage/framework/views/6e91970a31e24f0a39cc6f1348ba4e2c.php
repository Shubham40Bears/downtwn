<?php $__env->startSection('content'); ?>
<section id="" class="py-5">
    <div class="col-12 breadcrumb">
       <p class="text-center m-0"> 
        <a href="/">Home</a> > 
        <a href="<?php echo e(route('shop')); ?>">Shop</a> >
        <a href="#" class="active"><?php echo e($product->name); ?></a>
       </p>
    </div>
        <div class="container">
		<div class="card single-prod-card">
			<div class="container-fliud">
				<div class="wrapper row">
					<div class="preview col-md-6">
						<div class="preview-pic tab-content">
                          <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane <?php echo e($loop->first ? 'active' : ''); ?>" id="pic-<?php echo e($loop->index + 1); ?>"><img src="https://res.cloudinary.com/shubhambhattacharya/image/upload/<?php echo e($images); ?>" /></div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
						</div>
						<ul class="preview-thumbnail nav nav-tabs">
							
                          <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e($loop->first ? 'active' : ''); ?>"><a data-target="#pic-<?php echo e($loop->index + 1); ?>" data-toggle="tab"><img src="https://res.cloudinary.com/shubhambhattacharya/image/upload/w_150,h_150,c_thumb/<?php echo e($images); ?>" /></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
						
					</div>
					<div class="details col-md-6">
                        <p class="m-0">Downtwn.in</p>
						<h3 class="product-title nexa-bold"><?php echo e($product->name); ?></h3>
						<?php if($product->sales_price): ?> 
                                <p class="mt-2">
                                    <del class="text-muted">₹<?php echo e(number_format($product->price, 2)); ?></del> 
                                    <span class="text-success">₹<?php echo e(number_format($product->sales_price, 2)); ?></span>
                                </p>
                            <?php else: ?>
                                <p class="mt-2">
                                    <span class="text-success">₹<?php echo e(number_format($product->price, 2)); ?></span>
                                </p>
                            <?php endif; ?>
                            <p class="mini-title">Sizes</p>
                            <div class="size-options">
                                <?php $__currentLoopData = $product->stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="size-option">
                                        <input type="radio" name="size" value="<?php echo e($stock['size']); ?>" />
                                        <span class="size-label"><?php echo e($stock['size']); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div>
                                <p class="mini-title mt-4 mb-0">quantity</p>
                                <div class="quantity-selector">
                                    <button class="quantity-btn" id="decrease">-</button>
                                    <span class="quantity-count" id="quantity">1</span>
                                    <button class="quantity-btn" id="increase">+</button>
                                </div>
                            </div>
                            <div class="btn-section">
                                <a href="javascript:void(0)" class="btn btn-dwtwn mt-2 shine-button" id="addToCart">add to cart</a>
                                <a href="javascript:void(0)" class="btn btn-dwtwn mt-2 shine-button <?php echo e(route('addtocart')); ?>">buy now</a>
                            </div>
						
						
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    $(document).ready(function () {
        let quantity = 1;

        // Decrease quantity
        $('#decrease').click(function () {
            if (quantity > 1) {
                quantity--;
                $('#quantity').text(quantity);
            }
        });

        // Increase quantity
        $('#increase').click(function () {
            quantity++;
            $('#quantity').text(quantity);
        });

        $(document).on('click','#addToCart', function() {
            let productid = "<?php echo e($product->id); ?>";
            let formData = {
                productId: productid,
                quantity: $('#quantity').text()
            };
            toastr.options = {
                        "closeButton": true,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "timeOut": "3000",
                    };
            axios.post("<?php echo e(route('addtocart')); ?>", formData)
                .then(response => {
                    toastr.success('Product added to cart.', 'Done');

                })
                .catch(error => {
                    toastr.error('Something Went wrong, Please try again later', 'Error');
                    console.error(error);
                })
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.downtwn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/apple/Documents/projects/dtnew/wtflex_clone/resources/views/shop/productDetails.blade.php ENDPATH**/ ?>