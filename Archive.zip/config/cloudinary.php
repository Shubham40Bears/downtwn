<?php
return [
    'cloud_url' => env('CLOUDINARY_URL'),
];